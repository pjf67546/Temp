<!-- Source: https://edgedelta.com/company/about -->

# Learn More About Us - Edge Delta

# About Us

We have built the world’s first collaborative multi-agent platform for real-time streaming data: Collaborative AI Teammates. These proactive AI agents don’t just assist, they partner with you, analyzing logs, reviewing code, gathering context for incidents, and performing root cause analysis. Built on our enterprise-grade Telemetry Pipelines, they enable teams to act with speed and precision — and to focus on strategic decisions that drive better business outcomes.

!

## Our Mission

Enable teams to enter a new era of human-AI collaboration, where humans can focus on the strategic decisions that matter most.

We believe that AI should function as a proactive collaborator, not just an assistant you summon. Edge Delta’s AI Teammates are built on top of our enterprise-grade Telemetry Pipelines and watch your systems 24/7, surfacing the right insights at the right moment at petabyte-per-day scale. Our platform lets human teams maximize their impact and drive creative solutions, rather than spending valuable time and energy on busywork.

![star-sm](https://edgedelta.com/wp-content/themes/edgedelta/assets/images/star-sm.avif)

Seattle,

Washington United States

![star-sm](https://edgedelta.com/wp-content/themes/edgedelta/assets/images/star-sm.avif)

Founded in 2018

by Ozan Unlu and Fatih Yildiz

![star-sm](https://edgedelta.com/wp-content/themes/edgedelta/assets/images/star-sm.avif)

$82 million raised

Series B led by Quiet Capital

#### Our Investors

![Quiet](https://edgedelta.com/wp-content/uploads/2025/03/Quiet.svg)
![BamElevate](https://edgedelta.com/wp-content/uploads/2025/03/BamElevate.svg)
![earlybird](https://edgedelta.com/wp-content/uploads/2025/03/earlybird.svg)
![GeodesicCapital](https://edgedelta.com/wp-content/uploads/2025/03/GeodesicCapital.svg)
![KinVentures](https://edgedelta.com/wp-content/uploads/2025/03/KinVentures.svg)
![Menlo](https://edgedelta.com/wp-content/uploads/2025/03/Menlo.svg)
![Mac](https://edgedelta.com/wp-content/uploads/2025/03/Mac.svg)
![amijy](https://edgedelta.com/wp-content/uploads/2025/03/amijy.svg)
![ServiceNow](https://edgedelta.com/wp-content/uploads/2025/03/ServiceNow.svg)
![CiscoInvestments](https://edgedelta.com/wp-content/uploads/2025/03/CiscoInvestments.svg)

### Our Vision

A comprehensive platform that enables multi-agent collaboration across batched, static, event, and streaming data, making the human-in-the-loop faster and more informed than ever.

Most AI agents today lack real-time awareness and only know what you explicitly tell them. Edge Delta’s AI Teammates challenge that status quo, continuously gathering context from your streaming data. Some solutions can handle static knowledge bases, others handle real-time events in isolation, but Edge Delta is the only one that brings it all together with a unified approach.

!

!

## Leadership Team

![Ozan Unlu](https://edgedelta.com/wp-content/uploads/2025/10/Edgedelta-ozan-headshot.png)

Ozan Unlu

Founder & CEO

![Fatih Yildiz ](https://edgedelta.com/wp-content/uploads/2025/10/Edgedelta-fatih-headshot.png)

Fatih Yildiz

Founder & CTO

![Patrick Blahosky ](https://edgedelta.com/wp-content/uploads/2025/10/Edgedelta-Patrick-headshot.png)

Patrick Blahosky

Head of Sales

![Matt Meier](https://edgedelta.com/wp-content/uploads/2025/10/Edgedelta-Matt-Meier-headshot.png)

Matt Meier

Head of Field Eng

![Sarah Kricheff ](https://edgedelta.com/wp-content/uploads/2025/10/Edgedelta-Matt-Meier-headshot-1.png)

Sarah Kricheff

VP of Marketing

![Josh Wardini](https://edgedelta.com/wp-content/uploads/2025/10/Edgedelta-josh-wardini-headshot.png)

Josh Wardini

Head of Growth

![Jess Langmaid](https://edgedelta.com/wp-content/uploads/2025/10/Edgedelta-josh-wardini-headshot-1.png)

Jess Langmaid

VP People & Ops

![Ozgur Batur](https://edgedelta.com/wp-content/uploads/2025/10/Edgedelta-ozgur-headshot.png)

Ozgur Batur

Head of Eng

![Emrah Samdan](https://edgedelta.com/wp-content/uploads/2025/10/Edgedelta-Emrah-headshot.png)

Emrah Samdan

Head of Product

![Matt Miller](https://edgedelta.com/wp-content/uploads/2025/10/Edgedelta-Emrah-headshot-1.png)

Matt Miller

Head of Product

![Joan Pepin](https://edgedelta.com/wp-content/uploads/2025/10/Edgedelta-Emrah-headshot-2.png)

Joan Pepin

CISO

![Jabari Norton](https://edgedelta.com/wp-content/uploads/2025/10/Edgedelta-Emrah-headshot-3.png)

Jabari Norton

Partnerships

!

!

!

!

!

## Join Our Team

Our employees empower organizations around the globe to gain control and flexibility over their telemetry data. We are collaborative, curious, forward-looking, and deeply motivated to solve tough problems and delight our customers.

[See careers](https://edgedelta.com/company/careers)

!

!

## Our Values

!

Balance & Empowerment

We are thoughtful in our approach and execution. We take charge of decisions and output. We make time to celebrate, have fun, and recharge.

Integrity & Kindness

We instill trust and equity in everything we do and build. We support one another through well-intentioned and mindful actions. We promote open and honest communication for fairness in decision-making and foster an inclusive environment.

Curiosity & Vision

We enable our customers and team to be innovators. We challenge conventions to discover unexpected solutions. We iterate, reflect, and improve on everything we do.

### Our Founding

Edge Delta was founded by Ozan Unlu and Fatih Yildiz in 2018. After having experienced the challenges and limitations of traditional monitoring technologies from two different perspectives, their knowledge and experience — combined with recent advances in technology — allowed them to take a novel approach to solving immediate needs for DevOps, IT/Ops, SRE, and Security teams.

As a Dev Lead at Microsoft on the Azure and Security teams, and a tenured Senior Solutions Architect at Sumo Logic, Ozan has worked with hundreds of organizations from small startups to large enterprises to help implement and improve their architecture and observability infrastructure. Fatih, a highly respected and seasoned software engineer at Microsoft and Twitter, developed and operated complex distributed systems at petabyte scales.

Through their experiences, they both concluded that centralizing, indexing, and storing all raw telemetry data, at all times, is a model that needs to be improved to support real-time and operational use cases. Their history of working on projects as engineers at Microsoft brought them back together. Today, they are passionate about collaborating with engineering teams across the industry to learn and understand how Edge Delta can effectively solve prevalent problems in logs, metrics, traces, and events datasets.

### Our Experience

The founding team at Edge Delta bring a range of experiences and expertise to the table, allowing for the development of next-gen Telemetry Pipelines and AI-powered monitoring tools. With engineers from Twitter, Google, Microsoft, and Sumo Logic, the team has taken lessons learned from engineering cloud-scale technologies and applied them to a new, cloud-scale problem: how organizations control and manage exponential volumes of telemetry data. Our team understands the technical challenges involved with running and maintaining an observability and security stack at scale, and we place utmost importance on customer satisfaction, uptime, reliability, and data security.

![6697de8cf368b44db764f40b_Illustration (13)](https://edgedelta.com/wp-content/uploads/2025/03/6697de8cf368b44db764f40b_Illustration-13-502x1024.avif)