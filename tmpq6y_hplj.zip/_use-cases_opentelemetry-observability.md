<!-- Source: https://edgedelta.com/use-cases/opentelemetry-observability -->

# OpenTelemetry Observability

[use case](/use-cases)

# OpenTelemetry Observability

Edge Delta automatically structures logs in the OpenTelemetry schema, enabling you to:
Simplify OTel adoption
Break free from vendor lock-in
Easily investigate log data

[Request a Demo](https://edgedelta.com/request-demo)

!

!
!
!
!
!
!
!

!

!

![company logo](https://edgedelta.com/wp-content/uploads/2025/11/Remitly-new.svg)

"One thing that people are running into a lot is there may have been incidental PII in various systems. The ability to either filter that upfront, limit the scope of what you’re looking at, or shape it so that you don’t get personal data coming into the pipeline is going to be huge."

![Alex K](https://edgedelta.com/wp-content/uploads/2025/11/CleanShot-2025-11-05-at-23.43.45@2x-150x150.png)

Alex K

Director of Security, Remitly

![dashboard image](https://edgedelta.com/wp-content/uploads/2025/11/Alex-K-—-Quote-1-768x432.png)

![company logo](https://edgedelta.com/wp-content/uploads/2025/11/Remitly-new-100-x-100-px-4.svg)

"With a tool like this, you are learning from unexpected things that happen and when people finally jump in, the context has already been gathered, so they aren’t running around trying to stitch the picture together."

![Kyle Welsh](https://edgedelta.com/wp-content/uploads/2025/11/CleanShot-2025-11-06-at-00.14.41@2x-150x150.png)

Kyle Welsh

CIO, Seattle Bank

![dashboard image](https://edgedelta.com/wp-content/uploads/2025/11/Kyle-Welsh-—-Quote-1-768x432.png)

![company logo](https://edgedelta.com/wp-content/uploads/2025/11/Remitly-new-100-x-100-px-8.svg)

"DevOps is really hard when you’re doing 75% Ops, and 25% Dev. Automating your way out of log analysis, and some detection and reconciliation processes, is great."

![Dallas Thornton](https://edgedelta.com/wp-content/uploads/2025/11/CleanShot-2025-11-06-at-00.36.01@2x-150x150.png)

Dallas Thornton

Director, Digital and AI, PACCAR

![dashboard image](https://edgedelta.com/wp-content/uploads/2025/11/Dallas-Thornton-—-Quote-1-768x432.png)

![company logo](https://edgedelta.com/wp-content/uploads/2025/11/Remitly-new-100-x-100-px-11.svg)

"Data fuels all of AI. With Edge Delta’s AI release, it’s not just a static set of data — the streaming aspect makes it very fresh and most accurate and relevant to the task at hand."

![Mark Relph](https://edgedelta.com/wp-content/uploads/2025/11/CleanShot-2025-11-06-at-00.45.36@2x-150x150.png)

Mark Relph

Head of Data and AI, Partner GTM, AWS

![dashboard image](https://edgedelta.com/wp-content/uploads/2025/11/Mark-Relph-—-Quote-1-768x432.png)

![company logo](https://edgedelta.com/wp-content/uploads/2025/11/Remitly-new-100-x-100-px-9.svg)

"I’m very impressed by the sophistication, the innovation that’s happening here, and how valuable this is for the people that are really burdened by doing this work all the time.
"

![Ece Kamar, PhD](https://edgedelta.com/wp-content/uploads/2025/11/CleanShot-2025-11-06-at-00.50.48@2x-150x150.png)

Ece Kamar, PhD

CVP, AI Frontiers Lab Microsoft Research

![dashboard image](https://edgedelta.com/wp-content/uploads/2025/11/Ece-Kamar-—-Quote-1-768x432.png)

!

The Challenge

## Why is OTel Difficult to Implement?

While OpenTelemetry offers several benefits, its adoption comes with a unique set of challenges.

### Difficult Implementation

If your codebase or infrastructure is complex, integrating the framework can be challenging and labor intensive.

### Compatibility Issues

Ensuring compatibility with existing instrumentation and observability tools is a significant time investment.

### Migration Problems

Careful planning is required when moving from a different framework or using custom instrumentation.

The Solution

## Why Adopt OpenTelemetry?

OpenTelemetry is an open-source project from the Cloud Native Computing Foundation (CNCF). It aims to standardize how you collect metrics, events, logs, and traces, enabling the following benefits.

![Why Adopt OpenTelemetry?](https://edgedelta.com/wp-content/uploads/2025/02/66e0c2f7f93adab0eb873404_Migrations-in-hyperdrive-1536x843.png)

Mitigate Vendor Lock-In

Remove Long-Term Complexity

Enable Interoperability

!

!

!

!

## Ready to take the next step?

Learn more about our use cases and how we enable you to control all your telemetry data.

[Start Free Trial](https://edgedelta.com/start-free-trial)
[Request Demo](https://edgedelta.com/request-demo)

!

!

### “This is not just about doing what you used to do in the past, and doing it a little bit better. This is a new way to see this world of how we collect and manage our observability pipelines.”

Ben Kus, CTO, Box

[Read Case Study](/company/case-studies/box)

!

## Join Engineering Teams That Are Embracing AI

Get started with minimal effort, simply start adding connectors and start discussing with your out-of-the-box teammates now.

[Sign Up for Free](https://edgedelta.com/start-free-trial)

!