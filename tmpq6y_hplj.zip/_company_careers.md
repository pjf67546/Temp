<!-- Source: https://edgedelta.com/company/careers -->

# Careers - Edgedelta

# Careers

!
!

### Working at Edge Delta

We’re passionate about developing technology and solutions that our customers love. We promote a healthy work-life balance combined with career growth opportunities and an inclusive, collaborative culture. 
 
We’re proud to be an equal opportunity workplace. Whatever your age, race, religion, nationality, gender identity, or sexual orientation, we’re happy to have you.

!

!

!

1 - Engineering

Senior Software Engineer

[Details](https://edgedelta.com/company/careers/senior-software-engineer-2)

Remote

1 - Engineering

Senior Software Engineer

[Details](https://edgedelta.com/company/careers/senior-software-engineer)

Remote

!

## See Edge Delta in Action

Get hands-on in our interactive playground environment.

[Sign Up for Free](https://edgedelta.com/start-free-trial)

!