<!-- Source: https://edgedelta.com/company/videos -->

# Edge Delta Videos | Product Demos & Streaming Content

# Videos

Watch webinars, interviews, and more.

[Vimeo](https://vimeo.com/edgedelta)
[YouTube](https://www.youtube.com/@EdgeDelta)

!
!

!

!

[!](https://edgedelta.com/company/videos/sinclair-gains-cost-effective-ai-powered-observability-by-migrating-from-new-relic-to-edge-delta-2)

Case Study

[### Sinclair Gains Cost-Effective, AI-Powered Observability by Migrating from New Relic to Edge Delta](https://edgedelta.com/company/videos/sinclair-gains-cost-effective-ai-powered-observability-by-migrating-from-new-relic-to-edge-delta-2)

Sinclair, a leading media company, leveraged Edge Delta's Telemetry Pipelines to optimize their telemetry data volumes and migrate from New Relic onto Edge Delta's Observability Platform — where they unlocked real-time remediation, instant log-to-alert correlation, and a unified monitoring experience.

Dec 12, 2025

•

0 minutes

[Register](https://edgedelta.com/company/videos/sinclair-gains-cost-effective-ai-powered-observability-by-migrating-from-new-relic-to-edge-delta-2)

Categories

All

Search

[!](https://edgedelta.com/company/videos/sinclair-gains-cost-effective-ai-powered-observability-by-migrating-from-new-relic-to-edge-delta-2)

Case Study

[### Sinclair Gains Cost-Effective, AI-Powered Observability by Migrating from New Relic to Edge Delta](https://edgedelta.com/company/videos/sinclair-gains-cost-effective-ai-powered-observability-by-migrating-from-new-relic-to-edge-delta-2)

Dec 12, 2025

•

3:32

[!](https://edgedelta.com/company/videos/ai-teammates-office-hours-10-30-2025)

Webinar

[### AI Teammates Office Hours — 10/30/2025](https://edgedelta.com/company/videos/ai-teammates-office-hours-10-30-2025)

Oct 30, 2025

•

30:36

[!](https://edgedelta.com/company/videos/the-future-of-ai-in-observability-and-security-is-collaborative)

Product

[### The Future of AI in Observability and Security is Collaborative](https://edgedelta.com/company/videos/the-future-of-ai-in-observability-and-security-is-collaborative)

Oct 15, 2025

•

4:39

[!](https://edgedelta.com/company/videos/ai-teammates-product-walkthrough)

Product

[### AI Teammates Product Walkthrough](https://edgedelta.com/company/videos/ai-teammates-product-walkthrough)

Oct 8, 2025

•

6:32

[!](https://edgedelta.com/company/videos/introducing-ai-teammates)

Announcements

[### Introducing AI Teammates](https://edgedelta.com/company/videos/introducing-ai-teammates)

Oct 8, 2025

•

2:04

[!](https://edgedelta.com/company/videos/ai-ready-security-how-to-defend-against-ai-powered-attack-on-demand-webinar)

On-Demand Webinar

[### AI-Ready Security: How to Defend Against AI-Powered Attacks](https://edgedelta.com/company/videos/ai-ready-security-how-to-defend-against-ai-powered-attack-on-demand-webinar)

Sep 10, 2025

[!](https://edgedelta.com/company/videos/sinclair-gains-cost-effective-ai-powered-observability-by-migrating-from-new-relic-to-edge-delta)

Customer Story

[### Sinclair Gains AI-Powered Observability by Migrating from New Relic to Edge Delta — Extended Cut](https://edgedelta.com/company/videos/sinclair-gains-cost-effective-ai-powered-observability-by-migrating-from-new-relic-to-edge-delta)

Aug 27, 2025

•

4:06

[!](https://edgedelta.com/company/videos/seattle-fireside-chat-the-future-of-ai)

Events

[### Seattle Fireside Chat: The Future of AI](https://edgedelta.com/company/videos/seattle-fireside-chat-the-future-of-ai)

Aug 5, 2025

[!](https://edgedelta.com/company/videos/beyond-the-dashboard-building-telemetry-pipelines-for-petabyte-scale-systems-with-ozan-unlu)

Interview

[### Beyond the Dashboard: Building Telemetry Pipelines for Petabyte-Scale Systems with Ozan Unlu](https://edgedelta.com/company/videos/beyond-the-dashboard-building-telemetry-pipelines-for-petabyte-scale-systems-with-ozan-unlu)

May 22, 2025

•

39:37

[!](https://edgedelta.com/company/videos/nothing-ventured-interview-ozan-unlu-on-navigating-the-shift-from-technical-founder-to-commercial-leader)

Interview

[### Nothing Ventured Interview: Ozan Unlu on Navigating the Shift from Technical Founder to Commercial Leader](https://edgedelta.com/company/videos/nothing-ventured-interview-ozan-unlu-on-navigating-the-shift-from-technical-founder-to-commercial-leader)

Mar 17, 2025

•

49:36

[!](https://edgedelta.com/company/videos/ai-in-soc-with-ozan-unlu-from-edge-delta)

Interview

[### AI in SOC with Ozan Unlu from Edge Delta](https://edgedelta.com/company/videos/ai-in-soc-with-ozan-unlu-from-edge-delta)

Mar 14, 2025

[!](https://edgedelta.com/company/videos/employ-unlocks-intelligent-data-optimization-and-enhances-visibility-with-edge-delta)

Customer Story

[### Employ Unlocks Intelligent Data Optimization and Enhances Visibility with Edge Delta](https://edgedelta.com/company/videos/employ-unlocks-intelligent-data-optimization-and-enhances-visibility-with-edge-delta)

Feb 25, 2025

•

3:39

1[2](https://edgedelta.com/company/videos/page/2)

!

## See Edge Delta in Action

Get hands-on in our interactive playground environment.

[Sign Up for Free](https://edgedelta.com/start-free-trial)

!