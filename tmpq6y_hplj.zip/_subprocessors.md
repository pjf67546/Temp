<!-- Source: https://edgedelta.com/subprocessors -->

# Subprocessors | Edge Delta Data Processing Partners

# Subprocessors

Subscribe to be notified when new subprocessors are added.

[Subscribe with RSS](http://edge-delta.webflow.io/subprocessors/rss.xml)

!

!

!

Okta

Provides secure identity and access management solutions, enabling single sign-on (SSO), multi-factor authentication (MFA), and user provisioning for seamless and secure access to our platform.

AWS (US East and US West)

Snowflake

Provides a HubSpot warehouse to store data from Segment specific to Edge Delta’s HubSpot instance.

Slack

Slack is a messaging program designed specifically for the office,

AWS (US East and US West)

Zoom

Secure, reliable video platform powers all of your communication needs, including meetings, chat, phone, webinars, and online events.

AWS (US East and US West)

Zendesk

It provides software-as-a-service products related to customer support, sales, and other customer communications.

AWS (US East and US West)

Gong.io

Teams and leadership complete visibility into all deals, team performance, and market changes

AWS (US East and US West)

AWS

Cloud computing

AWS (US East and US West)

Atlassian

Jira is Atlassian’s proprietary and the most popular enterprise-grade issue tracking tool that allows users to track bugs, resolve issues, and manage project functions.

AWS (US East and US West)

Google

Email, SSO, Documents Storage, Google Workspace

Google Workspace/Google Drive US West/East

Hubspot

HubSpot’s free CRM powers your customer support, sales, and marketing with easy-to-use features like live chat, meeting scheduling, and email tracking.

HubSpot’s product infrastructure is hosted on Amazon Web Services (AWS) US

Azure

Cloud Infrastructure

Azure Storage (US East and US West)

Salesforce

It provides customer relationship management software and applications focused on sales, customer service, marketing automation, analytics, and application development.

AWS (US East and US West)