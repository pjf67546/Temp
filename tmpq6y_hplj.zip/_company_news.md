<!-- Source: https://edgedelta.com/company/news -->

# Blog: News | Edge Delta

# News

Read about Edge Delta in the news.

!
!

!

!

[!](https://www.prnewswire.com/news-releases/edge-delta-launches-ai-teammates-the-first-collaborative-multi-agent-platform-built-for-sre-security-and-devops-302578283.html?tc=eml_cleartime)

PR Newswire

[### Edge Delta Launches AI Teammates: The First Collaborative Multi-Agent Platform Built for SRE, Security, and DevOps](https://www.prnewswire.com/news-releases/edge-delta-launches-ai-teammates-the-first-collaborative-multi-agent-platform-built-for-sre-security-and-devops-302578283.html?tc=eml_cleartime)

Oct 8, 2025

[!](https://www.prnewswire.com/news-releases/edge-delta-appoints-patrick-blahosky-as-head-of-sales-to-support-global-demand-for-intelligent-telemetry-pipelines-302456962.html?tc=eml_cleartime)

PR Newswire

[### Edge Delta Appoints Patrick Blahosky as Head of Sales to Support Global Demand for Intelligent Telemetry Pipelines](https://www.prnewswire.com/news-releases/edge-delta-appoints-patrick-blahosky-as-head-of-sales-to-support-global-demand-for-intelligent-telemetry-pipelines-302456962.html?tc=eml_cleartime)

May 15, 2025

[!](https://www.prnewswire.com/news-releases/edge-delta-appoints-jabari-norton-as-head-of-channel-partnerships--alliances-302455445.html?tc=eml_cleartime)

PR Newswire

[### Edge Delta Appoints Jabari Norton as Head of Channel, Partnerships & Alliances](https://www.prnewswire.com/news-releases/edge-delta-appoints-jabari-norton-as-head-of-channel-partnerships--alliances-302455445.html?tc=eml_cleartime)

May 14, 2025

[!](https://www.prnewswire.com/news-releases/edge-delta-appoints-joan-pepin-as-chief-information-security-officer-ciso-302450415.html?tc=eml_cleartime)

PR Newswire

[### Edge Delta Appoints Joan Pepin as Chief Information Security Officer (CISO)](https://www.prnewswire.com/news-releases/edge-delta-appoints-joan-pepin-as-chief-information-security-officer-ciso-302450415.html?tc=eml_cleartime)

May 8, 2025

[!](https://www.prnewswire.com/news-releases/edge-delta-launches-an-mcp-server-ushering-in-a-new-era-of-ai-driven-observability-and-security-workflows-302436420.html?tc=eml_cleartime)

PR Newswire

[### Edge Delta Launches an MCP Server, Ushering in a New Era of AI-Driven Observability and Security Workflows](https://www.prnewswire.com/news-releases/edge-delta-launches-an-mcp-server-ushering-in-a-new-era-of-ai-driven-observability-and-security-workflows-302436420.html?tc=eml_cleartime)

Apr 23, 2025

[!](https://www.prnewswire.com/news-releases/edge-delta-announces-multi-processor-nodes-and-live-capture-to-enhance-telemetry-pipeline-management-302417041.html?tc=eml_cleartime)

PR Newswire

[### Edge Delta Announces Multi-Processor Nodes and Live Capture to Enhance Telemetry Pipeline Management](https://www.prnewswire.com/news-releases/edge-delta-announces-multi-processor-nodes-and-live-capture-to-enhance-telemetry-pipeline-management-302417041.html?tc=eml_cleartime)

Apr 1, 2025

[!](https://www.prnewswire.com/news-releases/edge-delta-unveils-new-microsoft-activity-pack-to-enhance-security-data-management-302406029.html?tc=eml_cleartime)

PR Newswire

[### Edge Delta Unveils New Microsoft Activity Pack to Enhance Security Data Management](https://www.prnewswire.com/news-releases/edge-delta-unveils-new-microsoft-activity-pack-to-enhance-security-data-management-302406029.html?tc=eml_cleartime)

Mar 19, 2025

[!](https://www.prnewswire.com/news-releases/edge-delta-announces-integration-with-dynatrace-for-optimized-observability-and-cost-efficiency-302394699.html)

PR Newswire

[### Edge Delta Announces Integration with Dynatrace for Optimized Observability and Cost Efficiency](https://www.prnewswire.com/news-releases/edge-delta-announces-integration-with-dynatrace-for-optimized-observability-and-cost-efficiency-302394699.html)

Mar 6, 2025

[!](https://www.prnewswire.com/news-releases/edge-delta-unlocks-intelligent-data-optimization-and-enhances-observability-for-employ-a-leading-hr-recruitment-tool-302387937.html?tc=eml_cleartime)

PR Newswire

[### Edge Delta Unlocks Intelligent Data Optimization and Enhances Observability for Employ, a Leading HR Recruitment Tool](https://www.prnewswire.com/news-releases/edge-delta-unlocks-intelligent-data-optimization-and-enhances-observability-for-employ-a-leading-hr-recruitment-tool-302387937.html?tc=eml_cleartime)

Feb 27, 2025

[!](https://www.prnewswire.com/news-releases/edge-delta-announces-general-availability-of-security-data-pipelines-revolutionizing-real-time-security-data-management-302378396.html?tc=eml_cleartime)

PR Newswire

[### Edge Delta Announces General Availability of Security Data Pipelines, Revolutionizing Real-Time Security Data Management](https://www.prnewswire.com/news-releases/edge-delta-announces-general-availability-of-security-data-pipelines-revolutionizing-real-time-security-data-management-302378396.html?tc=eml_cleartime)

Feb 19, 2025

[!](https://www.prnewswire.com/news-releases/edge-delta-announces-new-pack-for-fortinets-fortigate-firewall-logs-enhancing-real-time-threat-detection-and-operational-efficiency-302363508.html?tc=eml_cleartime)

PR Newswire

[### Edge Delta Announces New Pack for Fortinet’s FortiGate Firewall Logs, Enhancing Real-Time Threat Detection and Operational Efficiency](https://www.prnewswire.com/news-releases/edge-delta-announces-new-pack-for-fortinets-fortigate-firewall-logs-enhancing-real-time-threat-detection-and-operational-efficiency-302363508.html?tc=eml_cleartime)

Feb 8, 2025

[!](https://thenewstack.io/the-advent-of-automated-observability/)

The New Stack

[### The Advent of Automated Observability](https://thenewstack.io/the-advent-of-automated-observability/)

Mar 21, 2024

1[2](https://edgedelta.com/company/news/page/2)[3](https://edgedelta.com/company/news/page/3)[4](https://edgedelta.com/company/news/page/4)

!

## See Edge Delta in Action

Get hands-on in our interactive playground environment.

[Sign Up for Free](https://edgedelta.com/start-free-trial)

!