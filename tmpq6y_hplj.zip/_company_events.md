<!-- Source: https://edgedelta.com/company/events -->

# Events & Webinars | Connect with Edge Delta

# Events

Meet us at upcoming events and webinars to learn more about Edge Delta, our product, and customer success stories.

!
!

!

!

[!](https://edgedelta.com/company/events/gartner-iocs-in-las-vegas)
[### Let’s Meet at Gartner IOCS in Las Vegas!](https://edgedelta.com/company/events/gartner-iocs-in-las-vegas)

December 9–11, 2025

·

Las Vegas, Nevada

We’ll be at Gartner IOCS in Las Vegas this year, and we’d love to connect in person! Use the form to book a time that works best for you.

[!](https://edgedelta.com/company/events/aws-reinvent-in-las-vegas)
[### Let’s Meet at AWS re:Invent in Las Vegas!](https://edgedelta.com/company/events/aws-reinvent-in-las-vegas)

December 1–5, 2025

·

Las Vegas, Nevada

We’ll be at AWS re:Invent in Las Vegas this year, and we’d love to connect in person! Use the form to book a time that works best for you.

[!](https://edgedelta.com/company/events/kubecon-2025-atlanta)
[### Let’s Meet at KubeCon 2025 in Atlanta!](https://edgedelta.com/company/events/kubecon-2025-atlanta)

November 10–13, 2025

·

Atlanta, Georgia

We’ll be attending KubeCon North America this year. Use the form to book a time that works best for you — let’s connect in person!

[!](https://edgedelta.com/company/events/srecon-americas)
[### SRECON Americas](https://edgedelta.com/company/events/srecon-americas)

Mar 18–20, 2024

·

San Francisco, CA

SREcon24 Americas is a gathering of engineers who care deeply about site reliability, systems engineering, and working with complex distributed systems at scale. SREcon strives to challenge both those new to the profession as well as those who have been involved in it for decades.

[!](https://edgedelta.com/company/events/kubecon-eu)
[### KubeCon EU](https://edgedelta.com/company/events/kubecon-eu)

Mar 19–22, 2024

·

Paris, France

The Cloud Native Computing Foundation’s flagship conference gathers adopters and technologists from leading open source and cloud native communities in Paris, France from March 19 -22 2024.

!

## See Edge Delta in Action

Get hands-on in our interactive playground environment.

[Sign Up for Free](https://edgedelta.com/start-free-trial)

!