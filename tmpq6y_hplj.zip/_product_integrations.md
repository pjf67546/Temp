<!-- Source: https://edgedelta.com/product/integrations -->

# Seamless Integrations - Edge Delta

# Integrations

Edge Delta’s integrations make it easy for you to connect your machine data analytics and insights with the tools you already love.

![bg](https://edgedelta.com/wp-content/themes/edgedelta/assets/images/Frame-13967.svg)

![bg](https://edgedelta.com/wp-content/themes/edgedelta/assets/images/Frame-13969.svg)

![bg](https://edgedelta.com/wp-content/themes/edgedelta/assets/images/Frame-13968.svg)

![bg](https://edgedelta.com/wp-content/themes/edgedelta/assets/images/Frame-13971.svg)

![bg](https://edgedelta.com/wp-content/themes/edgedelta/assets/images/Frame-13970.svg)

![bg](https://edgedelta.com/wp-content/themes/edgedelta/assets/images/Frame-13972.svg)

!
!

!

!

Categories

Source

Destination

![Amazon Athena](https://edgedelta.com/wp-content/uploads/2025/03/66968124a4f4be5ac19c1339_logo-150x150.avif)

Amazon Athena

Analyze petabyte-scale data where it lives with ease and flexibility.

Destination

![Amazon CloudWatch](https://edgedelta.com/wp-content/uploads/2025/03/logo-1-150x150.avif)

Amazon CloudWatch

Observe and monitor resources and applications on AWS, on premises, and on other clouds.

[Learn more](https://docs.edgedelta.com/amazon-cloudwatch-destination-node/ )

Destination

![Amazon Kinesis](https://edgedelta.com/wp-content/uploads/2025/03/logo-2-150x150.avif)

Amazon Kinesis

Collect, process, and analyze real-time video and data streams.

Destination

![Amazon S3](https://edgedelta.com/wp-content/uploads/2025/03/66978868e621260948ff4412_logo-3-150x150.avif)

Amazon S3

Efficient cloud storage service.

[Learn more](https://docs.edgedelta.com/amazon-s3-archive/)

Destination

![Atlassian Jira](https://edgedelta.com/wp-content/uploads/2025/03/66978877f09f01a20503d3a1_logo-4-150x150.avif)

Atlassian Jira

Plan, track, and release world-class software.

[Learn more]( https://docs.edgedelta.com/jira/)

Source

![AWS](https://edgedelta.com/wp-content/uploads/2025/03/66978888d85c6e483bd8fcb6_logo-5-150x150.avif)

AWS

Services to help you build sophisticated applications with increased flexibility, scalability, and reliability.

Destination

![AWS Lambda](https://edgedelta.com/wp-content/uploads/2025/03/669788b1daed8ed6cd6ebf89_logo-6-150x150.avif)

AWS Lambda

Serverless, event-driven computing service.

[Learn more](https://docs.edgedelta.com/aws-lambda/)
[Read blog →](https://edgedelta.com/company/blog/aws-lambda-monitoring-with-edge-delta)

Source

![Azure](https://edgedelta.com/wp-content/uploads/2025/03/669788c6464a135813d15b0c_logo-7-150x150.avif)

Azure

Open and flexible cloud computing platform.

Destination

![Azure Functions](https://edgedelta.com/wp-content/uploads/2025/03/669788ede63657989f6a198a_logo-8-150x150.avif)

Azure Functions

Serverless solution that allows you to write less code, maintain less infrastructure, and save on costs.

[Learn more](https://docs.edgedelta.com/azure-functions-trigger/)
[Read blog →](https://edgedelta.com/company/blog/azure-function-monitoring-with-edge-delta)

Source

![Big Panda](https://edgedelta.com/wp-content/uploads/2025/03/669788fa7b77d919c4e79e43_logo-9-150x150.avif)

Big Panda

Transform all your IT data and knowledge into fast insight and automation.

[Learn more](https://docs.edgedelta.com/big-panda/)

Source

![BMC Remedy](https://edgedelta.com/wp-content/uploads/2025/03/669789104cbac501938cd7b5_logo-10-150x150.avif)

BMC Remedy

Solutions for automation, operations, service management, and enterprise-scale AI.

[Learn more](https://docs.edgedelta.com/remedy/)

Source

![Cisco AppDynamics](https://edgedelta.com/wp-content/uploads/2025/03/6697892255c5104cb2c94f6f_logo-11-150x150.avif)

Cisco AppDynamics

FSO and APM correlated with business metrics.

[Learn more](https://docs.edgedelta.com/appdynamics/)

Destination

![CrowdStrike Falcon LogScale](https://edgedelta.com/wp-content/uploads/2025/03/6697892ef88c9f15454dcf83_logo-12-150x150.avif)

CrowdStrike Falcon LogScale

Uncover security and reliability issues before they impact your business.

Destination

![Cribl](https://edgedelta.com/wp-content/uploads/2025/03/669789a15f8c51ea6a17b623_logo-13-150x150.avif)

Cribl

Data engine for IT and Security.

[Learn more](https://docs.edgedelta.com/cribl/)

Source

![Datadog](https://edgedelta.com/wp-content/uploads/2025/03/669789b9b9f67e31e7797ae3_logo-14-150x150.avif)

Datadog

Monitoring and security platform.

[Learn more](https://docs.edgedelta.com/datadog-output-node/ )
[Read blog →](https://edgedelta.com/company/blog/how-to-reduce-datadog-costs-with-edge-delta )

Destination

![DataSet](https://edgedelta.com/wp-content/uploads/2025/03/66978bc2e63657989f6be5e3_logo-15-150x150.avif)

DataSet

Enterprise infrastructure for live data queries, analytics, insights, and retention.

[Learn more](https://docs.edgedelta.com/scalyr-dataset/)

Destination

![DigitalOcean Spaces](https://edgedelta.com/wp-content/uploads/2025/03/66978bda4907827ae3740c5b_logo-16-150x150.avif)

DigitalOcean Spaces

Highly scalable and affordable object storage.

[Learn more](https://docs.edgedelta.com/digitalocean-spaces-output-node/)

Destination

![Docker](https://edgedelta.com/wp-content/uploads/2025/03/66978c2c742ebabf8df56c57_logo-17-1-150x150.avif)

Docker

Open-source platform for building, sharing, and running containerized applications.

[Learn more](https://docs.edgedelta.com/docker-input-node/)

Destination

![Dynatrace](https://edgedelta.com/wp-content/uploads/2025/03/66978c52df378d5e8af53759_logo-18-150x150.avif)

Dynatrace

Contextual analytics, AI, and automation.

[Learn more](https://docs.edgedelta.com/dynatrace/)

Destination

![Elastic](https://edgedelta.com/wp-content/uploads/2025/03/66978c8b98fd82568f13af57_logo-19-150x150.avif)

Elastic

Search through, analyze, and visualize large amounts of data.

[Learn more](https://docs.edgedelta.com/elastic/)

Destination

![Google Cloud](https://edgedelta.com/wp-content/uploads/2025/03/66978ca9294ac7131f3523d1_logo-21-150x150.avif)

Google Cloud

Cloud computing and storage services, hosted by Google.

[Learn more](https://docs.edgedelta.com/gcp/)

Destination

![Graylog](https://edgedelta.com/wp-content/uploads/2025/03/66978cdb16b8b78ef130efca_logo-23-150x150.avif)

Graylog

Self-managed, SSPL-licensed centralized log management solution.

[Learn more](https://docs.edgedelta.com/graylog/)

Destination

![Grafana Loki](https://edgedelta.com/wp-content/uploads/2025/03/66978cf0dc571485ccdfea2e_logo-24-150x150.avif)

Grafana Loki

Multi-tenant log aggregation system.

[Learn more](https://docs.edgedelta.com/loki-output-node/)

Destination

![Grafana](https://edgedelta.com/wp-content/uploads/2025/03/66978d17032bbe36fa0f99bf_logo-25-150x150.avif)

Grafana

Open source analytics & monitoring solution.

Destination

![Honeycomb](https://edgedelta.com/wp-content/uploads/2025/03/66978d2bb352cd88739fba70_logo-26-150x150.avif)

Honeycomb

Data unification tool that helps you solve problems faster within your distributed services.

[Learn more](https://docs.edgedelta.com/honeycomb/ )

Source

![IBM Object Storage](https://edgedelta.com/wp-content/uploads/2025/03/66978e0719f4963899a56da8_logo-27-150x150.avif)

IBM Object Storage

Managed data service offering an alternative to block and file storage.

[Learn more](https://docs.edgedelta.com/ibm-object-storage-output-node/ )

Destination

![InfluxDB](https://edgedelta.com/wp-content/uploads/2025/03/66978e1748080bf6b323bcb7_logo-28-150x150.avif)

InfluxDB

Leading platform for time series data.

[Learn more](https://docs.edgedelta.com/influxdb/ )

Source

![Kafka](https://edgedelta.com/wp-content/uploads/2025/03/66978e2be621260948032ecd_logo-29-150x150.avif)

Kafka

Open-source distributed event streaming platform.

[Learn more]( https://docs.edgedelta.com/kafka-output-node/ )
[Read blog →](https://edgedelta.com/company/blog/how-edge-deltas-telemetry-pipelines-architecture-delivers-cost-savings-and-efficiency )

Source

![Local Storage](https://edgedelta.com/wp-content/uploads/2025/03/66979039e81cfcd9668c7c2b_logo-31-150x150.avif)

Local Storage

Digital data stored on-premise.

Source

![Log Files](https://edgedelta.com/wp-content/uploads/2025/03/66979098f09f01a205093b95_logo-32-150x150.avif)

Log Files

Where applications and workflows write logs to.

Destination

![Logz.io](https://edgedelta.com/wp-content/uploads/2025/03/669790ae3c8f35e453dd907e_logo-33-150x150.avif)

Logz.io

Full-stack observability for modern software organizations.

[Learn more](https://docs.edgedelta.com/logzio/ )

Destination

![MinIO](https://edgedelta.com/wp-content/uploads/2025/04/channels4_profile-150x150.jpg)

MinIO

Enterprise class, AI-Ready object storage for every cloud.

[Learn more](https://docs.edgedelta.com/minio/)

Destination

![New Relic](https://edgedelta.com/wp-content/uploads/2025/03/6697910daf3b9b1467aef555_logo-37-150x150.avif)

New Relic

All-in-one observability platform.

[Learn more](https://docs.edgedelta.com/new-relic-output-node/ )

Destination

![OpenMetrics](https://edgedelta.com/wp-content/uploads/2025/03/669791225a668e43a7999edd_logo-38-150x150.avif)

OpenMetrics

Standardized format for exposing metric data.

[Learn more](https://docs.edgedelta.com/openmetrics-output-node/ )

Destination

![Snowflake](https://edgedelta.com/wp-content/uploads/2025/03/6697918316b8b78ef1344186_logo-42-150x150.avif)

Snowflake

Platform for storing, processing, and analyzing data.

Destination

![Splunk](https://edgedelta.com/wp-content/uploads/2025/03/669792189649cf4c7620e816_logo-44-150x150.avif)

Splunk

The key to enterprise resilience.

Destination

![StatsD](https://edgedelta.com/wp-content/uploads/2025/03/6697924579a461cb422597e4_logo-45-150x150.avif)

StatsD

Open-source solution for gathering metrics from a range of applications.

Destination

![Wavefront](https://edgedelta.com/wp-content/uploads/2025/03/669792704bec6d8386a80271_logo-47-150x150.avif)

Wavefront

SaaS-based metrics monitoring and analytics platform.

[Learn more](https://docs.edgedelta.com/wavefront/ )

Destination

![Webhook](https://edgedelta.com/wp-content/uploads/2025/03/6697928279a461cb4225d48c_logo-48-150x150.avif)

Webhook

Lightweight, event-driven communication between apps.

[Learn more](https://docs.edgedelta.com/webhook-output-node/)

Destination

![Windows Events](https://edgedelta.com/wp-content/uploads/2025/03/6697929509a5102d95538c74_logo-49-150x150.avif)

Windows Events

Windows-generated system, application, and security event logs.

[Learn more](https://docs.edgedelta.com/windows-events/ )

Destination

![Zenko CloudServer](https://edgedelta.com/wp-content/uploads/2025/03/669792a65f853e53e3859c92_logo-50-150x150.avif)

Zenko CloudServer

Open-source Node.js implementation of the Amazon S3 protocol.

[Learn more](https://docs.edgedelta.com/zenko-output-node/ )

Destination

![FluentD](https://edgedelta.com/wp-content/uploads/2025/03/66978c9da972b47410a2f884_logo-20-150x150.avif)

FluentD

Open source data collector.

[Learn more]( https://docs.edgedelta.com/fluentd-output-node/)

Source

![Google Cloud Functions](https://edgedelta.com/wp-content/uploads/2025/03/66978cbd44e2a083d1c5c002_logo-22-150x150.avif)

Google Cloud Functions

Serverless, event-driven functions within GCP.

Source

![Kubernetes](https://edgedelta.com/wp-content/uploads/2025/03/66978e499d8349a5d2891806_logo-30-150x150.avif)

Kubernetes

Open-source solution for managing containerized applications and services.

[Learn more](https://edgedelta.com/use-cases/monitor-kubernetes )
[Read blog →](https://edgedelta.com/company/blog/introducing-kubernetes-event-explorer )

Source

![Moogsoft](https://edgedelta.com/wp-content/uploads/2025/03/669790de5f853e53e384ab93_logo-35-150x150.avif)

Moogsoft

Ensure continuous availability with automated noise reduction.

[Learn more](https://docs.edgedelta.com/moogsoft/)

Source

![Networking](https://edgedelta.com/wp-content/uploads/2025/03/669790f48b7be4d99582362b_logo-36-150x150.avif)

Networking

Connecting devices for sharing information and resources.

Source

![PagerDuty](https://edgedelta.com/wp-content/uploads/2025/03/669791400ae067a9f520d758_logo-39-150x150.avif)

PagerDuty

Real-time operations platform.

[Learn more](https://docs.edgedelta.com/pagerduty/ )
[Read blog →](https://edgedelta.com/company/blog/introducing-monitors-a-better-way-to-manage-your-monitor-collection )

Source

![ServiceNow](https://edgedelta.com/wp-content/uploads/2025/03/669791543c138c9cbbd9102f_logo-40-150x150.avif)

ServiceNow

AI platform for business transformation.

[Learn more](https://docs.edgedelta.com/servicenow/ )

Source

![Slack](https://edgedelta.com/wp-content/uploads/2025/03/669791681c7d1a501fa0696e_logo-41-150x150.avif)

Slack

Popular team communication platform.

[Learn more](https://docs.edgedelta.com/slack/ )

Source

![SolarWinds Loggly](https://edgedelta.com/wp-content/uploads/2025/03/669792091ca53411f527baa7_logo-43-150x150.avif)

SolarWinds Loggly

Affordable, hosted analysis solution.

[Learn more](https://docs.edgedelta.com/loggly/ )

Source

![Microsoft Teams](https://edgedelta.com/wp-content/uploads/2025/03/6697925b81175b35017e6379_logo-46-150x150.avif)

Microsoft Teams

Application for team collaboration.

[Learn more](https://docs.edgedelta.com/teams-output-node/ )

Source

There are no items with this filter. Please try again.

!

!