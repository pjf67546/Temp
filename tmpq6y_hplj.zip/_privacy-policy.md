<!-- Source: https://edgedelta.com/privacy-policy -->

# Privacy Policy | Edge Delta Data Protection Commitment

# Privacy Policy

!

!

!

This Privacy Policy explains how information about you is collected, used and disclosed by Edge Delta, Inc. (collectively, “Edge Delta,” “we” or “us”) when you use our website https://edgedelta.com (“Website”), online products and monitoring services (“Platform”) (collectively, “Services”), or when you otherwise interact with us. This Privacy Policy also describes your choices regarding use, access and correction of personal information collected about you through our Services. Please read this Privacy Policy carefully and ensure that you understand it before you start to use our Services.

This Website is owned and operated by, or on behalf of, Edge Delta, Inc. (“we”, “our” or “us”). We are the data controller in respect of personal information of our users based in the European Union.

By accessing and using the Services, you acknowledge that you have read and understood the content of this Privacy Policy. We reserve the right to update this Privacy Policy from time to time. If we make changes, we will notify you by revising the date at the top of the Privacy Policy and, in some cases, we may provide you with additional notice (such as adding a statement to our homepage or sending you a notification). We encourage you to review the Privacy Policy whenever you access the Services or otherwise interact with us to stay informed about our information practices and the ways you can help protect your privacy.

### INFORMATION YOU PROVIDE TO US THROUGH THE SERVICES

When you access or use the Services we automatically collect information about you, including:

* Log Files: We gather certain information about your use of the Services, including the type of browser you use, access times, pages viewed, your IP address and the page you visited before navigating to the Services, and store it in log files. We do not monitor or log data collected from your servers when using the Services, but we may log or monitor information about your access to our Services.

### USE OF INFORMATION

We may use information about you to:

* Enable you to have full access to the Services;
* Provide, maintain and improve the Services;
* Provide and deliver the products and services you request, process transactions and send you related information, including confirmations and invoices,;
* Send you technical notices, updates, security alerts, and support and administrative messages;

* Respond to your comments, questions and requests, and provide customer support;
* Create your Edge Delta account and identify you when you sign-in to your account in accordance with your agreement with us;
* Communicate with you about products, services, offers, promotions, rewards, and events offered by Edge Delta and others, and provide news and information we think will be of interest to you;
* Monitor and analyze trends, usage and activities in connection with the Services;
* Detect, investigate and prevent fraud and other illegal activities and protect the rights and property of Edge Delta and others;
* Personalize and improve the Services and provide advertisements, content or features that match user profiles or interests;
* Notify you about important changes to the Services, including changes or updates to this Privacy Policy;
* Facilitate contests, sweepstakes and promotions and process and deliver entries and rewards;
* Link or combine with information we get from others to help understand your needs and provide you with better service;

### SHARING OF INFORMATION

We may share your personal information as follows or as otherwise described in this Privacy Policy:

* With vendors, consultants and other service providers we have vetted and approved who need access to such information to carry out work on our behalf only to the extent necessary for the performance of any contract we enter into with you. This includes companies providing the following services for our Website and/or Platform: hosting services, authentication services, cyber security and anti-fraud services, and advertising;
* In response to a request for information if we believe disclosure is permitted by, in accordance with, or required by, any applicable law, regulation or legal process such as to comply with a subpoena or applicable court order;
* With any person to whom disclosure is necessary to enable us to enforce our rights under this Privacy Policy or under any agreement we enter into with you or to protect the rights, property and safety of Edge Delta or third parties;
* In connection with, or during negotiations of, any merger, sale of Edge Delta assets, financing or acquisition of all or a portion of our business by another company;
* Between and among Edge Delta and all companies affiliated with Edge Delta who may act for us for any of the purposes set out in this Privacy Policy, including our current and future parents, affiliates, subsidiaries and other companies under common control and ownership

We may also share aggregated or de-identified information, which cannot reasonably be used to identify you.

To opt out, please visit our [“Do Not Sell / Share My Info”](/do-not-sell-share-my-info) page for detailed instructions.